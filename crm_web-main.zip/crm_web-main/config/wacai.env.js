'use strict'
// process.env.type = '"testing"'
// // 引入build.js文件
// require('./build')
module.exports = {
  NODE_ENV: '"presentation"',
  ENV_CONFIG: '"wacai"',
  API_ROOT: '"/api/"',
  CAD_PATH: '"../wacai/index.html"',
  CAD_INDEX: '"../wacai"' ,
  USER_APP: null,
  GET_BACK:'"https%3a%2f%2fapp.bluefire.top%2f%23%2fresult"'
}