'use strict'
module.exports = {
  NODE_ENV: '"presentation"',
  ENV_CONFIG: '"wacai"',
  API_ROOT: '"/"',
  CAD_PATH: '"../wacai/index.html"',
  CAD_INDEX: '"../wacai"' ,
  USER_APP: null,
  GET_BACK:'"https%3a%2f%2fapp.bluefire.top%2f%23%2fresult"'
}