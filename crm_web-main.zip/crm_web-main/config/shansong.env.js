'use strict'
module.exports = {
  NODE_ENV: '"positonsig"',
  ENV_CONFIG: '"shansong"',
  API_ROOT: '"https://app.bluefire.top:8010"',
  PACK_PATH:'"../shansong"',
  USER_APP: '"shansong/"',
  GET_BACK:'"https%3a%2f%2fapp.bluefire.top%2fshansong%2f%23%2fresult"'
}