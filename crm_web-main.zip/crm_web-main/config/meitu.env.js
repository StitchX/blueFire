'use strict'
module.exports = {
  NODE_ENV: '"testing"',
  ENV_CONFIG: '"meitu"',
  // API_ROOT: '"http://wxpay.zhouyujunlin.com:8202"',
  API_ROOT: '"https://app.bluefire.top:8010"',
  PACK_PATH:'"../meitu"',
  USER_APP: '"meitu/"',
  GET_BACK:'"https%3a%2f%2fapp.bluefire.top%2fmeitu%2f%23%2fresult"'
}