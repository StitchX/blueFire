'use strict'
module.exports = {
  NODE_ENV: '"worksyoumi"',
  ENV_CONFIG: '"youmi"',
  API_ROOT: '"https://app.bluefire.top:8010"',
  PACK_PATH:'"../youmi"',
  USER_APP: '"youmi/"',
  GET_BACK:'"https%3a%2f%2fapp.bluefire.top%2fyoumi%2f%23%2fresult"'
}