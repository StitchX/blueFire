'use strict'
module.exports = {
  NODE_ENV: '"worksdida"',
  ENV_CONFIG: '"dida"',
  API_ROOT: '"https://app.bluefire.top:8010"',
  PACK_PATH:'"../dida"',
  USER_APP: '"dida/"',
  GET_BACK:'"https%3a%2f%2fapp.bluefire.top%2fdida%2f%23%2fresult"'
}