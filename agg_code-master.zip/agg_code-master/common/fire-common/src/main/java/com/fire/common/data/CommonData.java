package com.fire.common.data;

public class CommonData {
    /**
     * 暂停分发，默认是暂停
     */
    public static Boolean sleepConsume = true;
    /**
     * 机器人地址
     */
    public static String robotUrl = null;
    /**
     * 项目名称
     */
    public static String projectName = null;


}
