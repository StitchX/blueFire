package com.fire.dto.log;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

/**
 * @author: dw
 * @Description:
 * @date: 2022-01-24 11:09
 */
@ApiModel("操作日志实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("log_info")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LogInfo {

    @ApiModelProperty("主键")
    @TableId(value = "log_info_id",type = IdType.AUTO)
    private Long logInfoId;

    //@ApiModelProperty("监管(局)所ID")
    //private Long supervisionId;

    @ApiModelProperty("操作人")
    private String name;

    @ApiModelProperty("操作内容")
    private String content;

    @ApiModelProperty("操作IP")
    private String ip;

    @ApiModelProperty("操作时间")
    private Timestamp operateTime;

    @ApiModelProperty("模块")
    private String module;

    @ApiModelProperty("操作参数")
    private String params;

}
