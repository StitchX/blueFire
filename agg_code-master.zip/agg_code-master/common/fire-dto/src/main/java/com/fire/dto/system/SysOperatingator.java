package com.fire.dto.system;

import lombok.Data;

/**
 * @author: liuliu
 * @ClassName: SysOperatingator
 * @Description: 系统操作者
 * @date: 2021-05-18 11:57
 */
@Data
public class SysOperatingator {

    private String creator;


}
