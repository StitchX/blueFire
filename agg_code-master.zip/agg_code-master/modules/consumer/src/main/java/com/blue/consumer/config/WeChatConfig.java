package com.blue.consumer.config;

/**
 * @author fcq
 * @version v2.0.2.consumer
 * @description 微信授权配置
 * @date 2022/3/9 10:47
 */
public class WeChatConfig {

    public static String appid = "wxc342312f82c01247";

    public static String secret = "0ceba7671d0a0afe493cdcbdbd5bbcda";
}
