package com.blue.nongxin.dto;


/**
 * Auto-generated: 2022-03-01 18:7:12
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class JsonRootBean {

    private String pagyPayTxnSsn;
    private String clientId;
    private String txnType;
    private String origReqTime;
    private String userId;
    private String payAmt;
    private String orderState;
    private String origReqSsn;
    private String origRespSsn;
    private String origRespTime;
    private String pagyTxnSsn;
    private String tpamTxnSsn;
    private String txnAmt;
    public void setPagyPayTxnSsn(String pagyPayTxnSsn) {
        this.pagyPayTxnSsn = pagyPayTxnSsn;
    }
    public String getPagyPayTxnSsn() {
        return pagyPayTxnSsn;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
    public String getClientId() {
        return clientId;
    }

    public void setTxnType(String txnType) {
        this.txnType = txnType;
    }
    public String getTxnType() {
        return txnType;
    }

    public void setOrigReqTime(String origReqTime) {
        this.origReqTime = origReqTime;
    }
    public String getOrigReqTime() {
        return origReqTime;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getUserId() {
        return userId;
    }

    public void setPayAmt(String payAmt) {
        this.payAmt = payAmt;
    }
    public String getPayAmt() {
        return payAmt;
    }

    public void setOrderState(String orderState) {
        this.orderState = orderState;
    }
    public String getOrderState() {
        return orderState;
    }

    public void setOrigReqSsn(String origReqSsn) {
        this.origReqSsn = origReqSsn;
    }
    public String getOrigReqSsn() {
        return origReqSsn;
    }

    public void setOrigRespSsn(String origRespSsn) {
        this.origRespSsn = origRespSsn;
    }
    public String getOrigRespSsn() {
        return origRespSsn;
    }

    public void setOrigRespTime(String origRespTime) {
        this.origRespTime = origRespTime;
    }
    public String getOrigRespTime() {
        return origRespTime;
    }

    public void setPagyTxnSsn(String pagyTxnSsn) {
        this.pagyTxnSsn = pagyTxnSsn;
    }
    public String getPagyTxnSsn() {
        return pagyTxnSsn;
    }

    public void setTpamTxnSsn(String tpamTxnSsn) {
        this.tpamTxnSsn = tpamTxnSsn;
    }
    public String getTpamTxnSsn() {
        return tpamTxnSsn;
    }

    public void setTxnAmt(String txnAmt) {
        this.txnAmt = txnAmt;
    }
    public String getTxnAmt() {
        return txnAmt;
    }

}