package com.blue.business.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fire.dto.entity.BankAppointment;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BankAppointmentMapper extends BaseMapper<BankAppointment> {
}
