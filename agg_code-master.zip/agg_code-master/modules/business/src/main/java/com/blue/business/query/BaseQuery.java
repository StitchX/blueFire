package com.blue.business.query;

import lombok.Data;

/**
 * @author : [Cohen]
 * @version : [v1.0]
 * @createTime : [2022/3/23 15:06]
 */
@Data
public class BaseQuery {
    private Long id;
}
