package com.blue.business.vo;

import lombok.Data;

@Data
public class CategoryVo {
    private Long categoryId;
    private String categoryName;
}
