package com.blue.business.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fire.dto.entity.BusinessLicense;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BusinessLicenseMapper extends BaseMapper<BusinessLicense> {
}
