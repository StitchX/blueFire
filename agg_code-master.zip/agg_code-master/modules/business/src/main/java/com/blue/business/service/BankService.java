package com.blue.business.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fire.dto.entity.Bank;

/**
 * @author : [Cohen]
 * @version : [v1.0]
 * @createTime : [2022/3/23 15:48]
 */
public interface BankService extends IService<Bank> {
}
