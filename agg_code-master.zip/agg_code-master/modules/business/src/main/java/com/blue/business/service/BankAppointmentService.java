package com.blue.business.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fire.dto.entity.BankAppointment;

public interface BankAppointmentService extends IService<BankAppointment> {
}
