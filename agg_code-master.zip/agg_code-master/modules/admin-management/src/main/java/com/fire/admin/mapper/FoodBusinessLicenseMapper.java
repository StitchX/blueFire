package com.fire.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fire.admin.entity.FoodBusinessLicense;

public interface FoodBusinessLicenseMapper extends BaseMapper<FoodBusinessLicense> {
}
