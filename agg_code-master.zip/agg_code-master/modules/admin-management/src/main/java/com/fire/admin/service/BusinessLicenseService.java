package com.fire.admin.service;

public interface BusinessLicenseService {

}
