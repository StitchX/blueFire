package com.fire.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fire.admin.entity.WxUserInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WxUserInfoMapper extends BaseMapper<WxUserInfo> {
}
