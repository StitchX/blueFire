package com.fire.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fire.admin.entity.BusinessLicense;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BusinessLicenseMapper extends BaseMapper<BusinessLicense> {
}
