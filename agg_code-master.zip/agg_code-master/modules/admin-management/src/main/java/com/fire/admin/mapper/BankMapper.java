package com.fire.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fire.admin.entity.Bank;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BankMapper extends BaseMapper<Bank> {
}
