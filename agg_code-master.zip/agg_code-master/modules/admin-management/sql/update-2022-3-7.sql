alter table bank_info
    modify id bigint auto_increment;

alter table food_business_license
    modify food_business_license_id bigint auto_increment comment '主键';

