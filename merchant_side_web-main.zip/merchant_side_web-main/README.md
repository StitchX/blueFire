# 智慧监管放心码商户端(小程序)前端代码
## 开发工具 

[HbuilderX](https://www.dcloud.io/hbuilderx.html)

## 开发框架 uni-app(Vue)

## UI框架 

[uView](https://www.uviewui.com/components/intro.html)
[uni-ui](https://uniapp.dcloud.io/component/)

>uni-app内置基本组件uni-ui,uVie为该基础上扩展ui组件,可互相兼容使用