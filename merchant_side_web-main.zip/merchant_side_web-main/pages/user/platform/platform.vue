<template>
	<view>
		<view class="platformText">
			“三码合一，一店一码”智慧监管系统是市场监督局监制的“互联网+”便民服务平台。引入“互联网+监管”模式，打造市场监管大数据平台，实现食安监管、支付与评论、疫情防控多功能的“一码通”。
			消费者只需扫描一个码，即可在支付前查询商户监管记录、了解食品安全信息，支付后可对商家公开评论和投诉，共同参与食品安全社会共治。同时自动同步疫情防控信息，充分保障消费者的消费环境安全。
			商户只需展示一个码，即可实现“监管及食品安全信息展示”、“收款及对账”和“疫情信息上报及同步”三项功能，实现商户自主参与食品安全社会共治。
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
 .platformText{
	 padding: 10px;
	 font-size: 14px;
 }
</style>

